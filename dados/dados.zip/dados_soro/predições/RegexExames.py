import re
import pandas as pd
from scipy.stats import linregress
import numpy as np
import os 
import matplotlib.pyplot as plt
from pathlib import Path


def find_all_x(file_path,new_name):
    with open(file_path, 'r') as file:
        content = file.read()

    x_matches = re.findall(r'Resposta:.*', content,re.IGNORECASE)
    with open(new_name, 'w') as file:
        for i in x_matches:
            file.write(f"{i},\n")
            print(i)

def subs_all(file_path,value,substitution):
    with open(file_path, 'r') as file:
        content = file.read()
        file.close()

    x_matches = re.sub(value,substitution, content)
    with open(file_path, 'w') as file:
        file.write(x_matches)
    print(x_matches)

def apply_subs(Adress):
    subs_all(Adress,value="Raciocínio.*",substitution="")
    subs_all(Adress,value="([0-9]),([0-9])",substitution=lambda x: f"{x.group(1)}.{x.group(2)}")
    subs_all(Adress,value="\*",substitution="")
    subs_all(Adress,value=" ",substitution="")
    subs_all(Adress,value=",",substitution="")
    subs_all(Adress,value="-",substitution="")
    subs_all(Adress,value="<",substitution="")
    subs_all(Adress,value="=",substitution="")
    subs_all(Adress,value=">",substitution="")
    subs_all(Adress,value="\[",substitution="")
    subs_all(Adress,value="\]",substitution="")
    subs_all(Adress,value="([A-Z])",substitution= lambda x: x.group(1).lower())
    subs_all(Adress,value="reativo",substitution="reagente")
    subs_all(Adress,value="nãoreagente",substitution="não_reagente")
    subs_all(Adress,value="naoreagente",substitution="não_reagente")
    subs_all(Adress,value="resposta:",substitution="resposta:|")
    subs_all(Adress,value="([0-9])indeterminado",substitution=lambda x: f"{x.group(1)}|indeterminado")
    subs_all(Adress,value="([0-9])reagente",substitution=lambda x: f"{x.group(1)}|reagente")
    subs_all(Adress,value="([0-9])não_reagente",substitution=lambda x: f"{x.group(1)}|não_reagente")




def clean_data():
    file = Path("/home/rose/Área de Trabalho/pesq2/dados/dados_soro/predições/llama/FewShot")
    for child in file.iterdir():
        try:
            find_all_x(child,"/home/rose/Área de Trabalho/pesq2/dados/dados_soro/predições/aux.txt")
            apply_subs("/home/rose/Área de Trabalho/pesq2/dados/dados_soro/predições/aux.txt")
            os.rename('/home/rose/Área de Trabalho/pesq2/dados/dados_soro/predições/aux.txt',
                        '/home/rose/Área de Trabalho/pesq2/dados/dados_soro/predições/aux.csv')

            data = pd.read_csv("/home/rose/Área de Trabalho/pesq2/dados/dados_soro/predições/aux.csv",sep="|",header=None)
            data.astype({1:"float16",2:"str"})
            def acerto(row):
                if (row[1] > 0.9 and row[2] == "reagente") or (row[1] <= 0.9 and row[2] == "não_reagente"):
                    return 1
                else: 
                    return 0

            data["acerto"] = data.apply(acerto,axis = 1)
            data = data.dropna()
            data.to_csv(child.with_suffix(".csv"),index=False,sep="|")
        except:
            print(child)

def print_results():
    file = Path("/home/rose/Área de Trabalho/pesq2/dados/dados_soro/predições/deepseek/temp")
    for child in file.iterdir():
        acerto,erro, = 0,0
        if child.suffix == ".csv":
            data = pd.read_csv(child,sep="|")
            acerto += len(data[data["acerto"] == 1])
            erro += len(data[data["acerto"] == 0])
            print(child)
            print(acerto/(acerto+erro))